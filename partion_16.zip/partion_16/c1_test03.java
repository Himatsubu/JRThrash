import net.njlab.sample.annotation.*;
//分割数16

public class c1_test03{
	private static final float[] u = new float[484];
	private static final float[] uu= new float[484];
	private static final float[] q = new float[484];

	static final sub00 sub00    = new sub00(); //1-6,1-6
	static final sub01 sub01    = new sub01(); //5-11,1-6
	static final sub02 sub02    = new sub02(); //10-16,1-6
	static final sub03 sub03    = new sub03(); //15-21,1-6
	static final sub04 sub04    = new sub04(); //1-6,5-11
	static final sub05 sub05    = new sub05(); //5-11,5-11
	static final sub06 sub06    = new sub06(); //10-16,5-11
	static final sub07 sub07    = new sub07(); //15-21,5-11
	static final sub08 sub08    = new sub08(); //1-6,10-16
	static final sub09 sub09    = new sub09(); //5-11,10-16
	static final sub10 sub10    = new sub10(); //10-16,10-16
	static final sub11 sub11    = new sub11(); //15-21,10-16
	static final sub12 sub12    = new sub12(); //1-6,15-21
	static final sub13 sub13    = new sub13(); //5-11,15-21
	static final sub14 sub14    = new sub14(); //10-16,15-21
	static final sub15 sub15    = new sub15(); //15-21,15-21

        @JRThrashUnroll(unrollNum=20, loopVariableName="j",unrollType=JRThrashUnroll.copyLoopVar)

	public void run(){
	//public static void main(String[] args){
		int k,j,n,mx,my,nlast;
		float dx,dy;
		int tmp1,tmp2,tmp3,tmp4,tmp5,tmp6,tmp7,tmp8,tmp9;

		mx=21;
		my=21;
		dx = 0.05f;
		dy = 0.05f;
		nlast=2;
			
//	熱源項の定義と初期条件
	for (k = 1; k <= my; k++)
	{
		for (j = 1; j<= mx; j++)
		{
			 q[j*21+k] = 100f*dx*(j-1)*dy*(k-1);
			 u[j*21+k] = 0f;
			uu[j*21+k] = 0f;
		}
	}
	
//	計算ループ	
	for(n=1;n<=nlast;n++){
//	境界条件
		for (k = 1; k <= my; k++)
		{
			u[1*21+k] = 0.5f;
			u[mx*21+k]= 0f;
		}
		
		for (j = 1; j <= mx; j++)
		{
			u[j*21+1] = 1.f;
			u[j*21+my]= 0f;
		}
		
		//クラスに配列をこぴー

		//1-6,1-6 36
		for(k=1;k<=6;k++)
		{
			for(j=1;j<=6;j++)
			{
				tmp1=j*21+k;
				sub00.u[tmp1]=u[tmp1];
				sub00.q[tmp1]=q[tmp1];
			}
		}
		//5-11,1-6 42
		for(k=5;k<=11;k++)
		{
			for(j=1;j<=6;j++)
			{
				tmp1=j*21+k;
				tmp2=j*21+k+5;
				tmp3=j*21+k+10;
	
				sub01.u[tmp1]=u[tmp1];
				sub01.q[tmp1]=q[tmp1];
				sub02.u[tmp2]=u[tmp2];
				sub02.q[tmp2]=q[tmp2];
				sub03.u[tmp3]=u[tmp3];
				sub03.q[tmp3]=q[tmp3];
			}
		}

		//1-6,5-11 42
		for(k=1;k<=6;k++)
		{
			for(j=5;j<=11;j++)
			{	
				tmp1=j*21+k;
				tmp2=(j+5)*21+k;
				tmp3=(j+10)*21+k;

				sub04.u[tmp1]=u[tmp1];
				sub04.q[tmp1]=q[tmp1];
				sub08.u[tmp2]=u[tmp2];
				sub08.q[tmp2]=q[tmp2];
				sub12.u[tmp3]=u[tmp3];
				sub12.q[tmp3]=q[tmp3];
			}
		}

		//5-11,5-11 49
		for(k=5;k<=11;k++)
		{
			for(j=5;j<=11;j++)
			{
				tmp1=j*21+k;
				tmp2=j*21+k+5;
				tmp3=j*21+k+10;
				tmp4=(j+5)*21+k;
				tmp5=(j+5)*21+k+5;
				tmp6=(j+5)*21+k+10;
				tmp7=(j+10)*21+k;
				tmp8=(j+10)*21+k+5;
				tmp9=(j+10)*21+k+10;

				sub05.u[tmp1]=u[tmp1];
				sub05.q[tmp1]=q[tmp1];
				sub06.u[tmp2]=u[tmp2];
				sub06.q[tmp2]=q[tmp2];
				sub07.u[tmp3]=u[tmp3];
				sub07.q[tmp3]=q[tmp3];

				sub09.u[tmp4]=u[tmp4];
				sub09.q[tmp4]=q[tmp4];
				sub10.u[tmp5]=u[tmp5];
				sub10.q[tmp5]=q[tmp5];
				sub11.u[tmp6]=u[tmp6];
				sub11.q[tmp6]=q[tmp6];

				sub13.u[tmp7]=u[tmp7];
				sub13.q[tmp7]=q[tmp7];
				sub14.u[tmp8]=u[tmp8];
				sub14.q[tmp8]=q[tmp8];
				sub15.u[tmp9]=u[tmp9];
				sub15.q[tmp9]=q[tmp9];
			}
		}	
		


		
		sub00.start();
		sub01.start();
		sub02.start();
		sub03.start();
		sub04.start();
		sub05.start();
		sub06.start();
		sub07.start();
		sub08.start();
		sub09.start();
		sub10.start();
		sub11.start();
		sub12.start();
		sub13.start();
		sub14.start();
		sub15.start();
	
		try{
			sub00.join();
			sub01.join();
			sub02.join();
			sub03.join();
			sub04.join();
			sub05.join();
			sub06.join();
			sub07.join();
			sub08.join();
			sub09.join();
			sub10.join();
			sub11.join();
			sub12.join();
			sub13.join();
			sub14.join();
			sub15.join();
		}catch(Exception e){}

		//2-5,2-5
		for(k=2;k<=5;k++)
		{
			for(j=2;j<=5;j++)
			{
				tmp1=j*21+k;
				u[tmp1]=sub00.result[tmp1];
			}
		}
		//6-10,2-5
		for(k=6;k<=10;k++)
		{
			for(j=2;j<=5;j++)
			{
				tmp1=j*21+k;
				tmp2=j*21+k+5;
				tmp3=j*21+k+10;

				u[tmp1]=sub01.result[tmp1];
				u[tmp2]=sub02.result[tmp2];
				u[tmp3]=sub03.result[tmp3];
			}
		}

		//2-5,6-10
		for(k=2;k<=5;k++)
		{
			for(j=6;j<=10;j++)
			{
				tmp1=j*21+k;
				tmp2=(j+5)*21+k;
				tmp3=(j+10)*21+k;

				u[tmp1]=sub04.result[tmp1];
				u[tmp2]=sub08.result[tmp2];
				u[tmp3]=sub12.result[tmp3];
			}
		}
		//6-10,6-10
		for(k=6;k<=10;k++)
		{
			for(j=6;j<=10;j++)
			{
				tmp1=j*21+k;
				tmp2=j*21+k+5;
				tmp3=j*21+k+10;
				tmp4=(j+5)*21+k;
				tmp5=(j+5)*21+k+5;
				tmp6=(j+5)*21+k+10;
				tmp7=(j+10)*21+k;
				tmp8=(j+10)*21+k+5;
				tmp9=(j+10)*21+k+10;

				u[tmp1]=sub05.result[tmp1];
				u[tmp2]=sub06.result[tmp2];
				u[tmp3]=sub07.result[tmp3];

				u[tmp4]=sub09.result[tmp4];
				u[tmp5]=sub10.result[tmp5];
				u[tmp6]=sub11.result[tmp6];

				u[tmp7]=sub13.result[tmp7];
				u[tmp8]=sub14.result[tmp8];
				u[tmp9]=sub15.result[tmp9];
			}
		}


		

/*
		for(k=2;k<=my-1;k++)
		{
			for(j=2;j<=mx-1;j++)
			{
				System.out.println(k+" "+j+" "+u[j*21+k]);
			}
		}
*/
			
		}
		//System.out.println(u[10*21+10]);
	}
}
